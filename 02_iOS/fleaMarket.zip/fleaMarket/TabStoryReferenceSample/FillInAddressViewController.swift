//
//  FillInAddressViewController.swift
//  fleaMarket
//
//  Created by Kero on 2016/6/18.
//  Copyright © 2016年 ColorKit. All rights reserved.
//

import UIKit
import MapKit

class FillInAddressViewController: UIViewController {
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var addressTextField: UITextField!
    
    @IBAction func submitAddressButtonAction(sender: UIButton) {

        if addressTextField.text != "" {
            
//            let location: String = "\(addressTextField.text)"
//            let geocoder: CLGeocoder = CLGeocoder()
//            geocoder.geocodeAddressString(location,completionHandler: {(placemarks: [CLPlacemark]?, error: NSError?) -> Void in
//                if (placemarks?.count > 0) {
//                    let topResult: CLPlacemark = (placemarks?[0])!
//                    let placemark: MKPlacemark = MKPlacemark(placemark: topResult)
//                    var region: MKCoordinateRegion = self.mapView.region
//                    
//                    region.center.latitude = (placemark.location?.coordinate.latitude)!
//                    region.center.longitude = (placemark.location?.coordinate.longitude)!
//                    
//                    region.span = MKCoordinateSpanMake(0.5, 0.5)
//                    
//                    self.mapView.setRegion(region, animated: true)
//                    self.mapView.addAnnotation(placemark)
//                }
//                
//                if error != nil {
//                print (error)
//                }
//            })
            
            var address = "\(addressTextField.text)"
            var geocoder = CLGeocoder()
            geocoder.geocodeAddressString(address, completionHandler: {(placemarks: [AnyObject]!, error: NSError!) -> Void in
                if let placemark = placemarks?[0] as? CLPlacemark
                {
                    
                    self.initialLocation = placemark.location
                    self.centerMapOnLocation(self.initialLocation)
                    
                }
            })
            
           
//            addressArray.append(addressTextField.text!)
//            NSUserDefaults.standardUserDefaults().setObject(addressArray, forKey: "tasks")
//            navigationController?.popViewControllerAnimated(true)
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func centerMapOnLocation(location: CLLocation)
    {
        
        let regionRadius: CLLocationDistance = 1000
        
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    

}
