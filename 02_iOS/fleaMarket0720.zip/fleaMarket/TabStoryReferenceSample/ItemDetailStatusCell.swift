//
//  ItemDetailStatusCell.swift
//  fleaMarket
//
//  Created by Kero on 2016/7/17.
//  Copyright © 2016年 ColorKit. All rights reserved.
//

import UIKit

class ItemDetailStatusCell: UITableViewCell {
    @IBOutlet weak var leftLabel: UILabel!
    @IBOutlet weak var rightLabel: UILabel!
}
